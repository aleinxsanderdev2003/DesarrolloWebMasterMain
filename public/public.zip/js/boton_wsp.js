document.getElementById('whatsapp-button').addEventListener('click', function() {
    window.open('https://wa.me/1234567890');
});
