<!-- resources/views/productos/sistemas-web.blade.php -->

@extends('productos.index')

@section('contenido')
    <!-- Contenido específico de la categoría 'Sistemas Web' -->
    <h1>Categoría: Sistemas Web</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Sistemas Web' -->
@endsection
