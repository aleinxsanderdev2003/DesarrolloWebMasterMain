<!-- resources/views/productos/paginas-web.blade.php -->


<?php $__env->startSection('contenido'); ?>
    <!-- Contenido específico de la categoría 'Páginas Web' -->
    <h1>Categoría: Páginas Web</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Páginas Web' -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('productos.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMaster\resources\views/productos/PaginasWeb.blade.php ENDPATH**/ ?>