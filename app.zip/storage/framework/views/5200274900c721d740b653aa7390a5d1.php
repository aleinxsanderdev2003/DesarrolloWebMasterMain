<!-- resources/views/productos/sistemas-web.blade.php -->



<?php $__env->startSection('contenido'); ?>
    <!-- Contenido específico de la categoría 'Sistemas Web' -->
    <h1>Categoría: Sistemas Web</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Sistemas Web' -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('productos.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMaster\resources\views/productos/SistemasWeb.blade.php ENDPATH**/ ?>