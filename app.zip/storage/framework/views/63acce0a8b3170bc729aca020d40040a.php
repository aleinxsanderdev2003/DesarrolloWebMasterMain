<!-- resources/views/productos/landing-page.blade.php -->



<?php $__env->startSection('contenido'); ?>
    <!-- Contenido específico de la categoría 'Landing Page' -->
    <h1>Categoría: Landing Page</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Landing Page' -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('productos.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMaster\resources\views/productos/LandingPage.blade.php ENDPATH**/ ?>