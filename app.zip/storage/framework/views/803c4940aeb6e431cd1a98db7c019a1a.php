<?php $__env->startSection('contenido'); ?>
<div class="row mt-3">
    <div class="col">
        <h1 class="page-title">Todos los Productos</h1>
    </div>
</div>

<div class="row">
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="<?php echo e(asset('img/products/' . $producto->imagen)); ?>" class="card-img-top" alt="<?php echo e($producto->nombre); ?>">
                <div class="card-body">
                    <h2 class="card-title text-black"><?php echo e($producto->nombre); ?></h2>
                    <p class="card-text"><?php echo e($producto->descripcion); ?></p>
                    <p class="price">
                        <del>$<?php echo e(number_format($producto->precio + 5, 2)); ?></del>
                        <ins>$<?php echo e(number_format($producto->precio, 2)); ?></ins>
                    </p>
                    <a href="#" class="btn btn-primary">Añadir al carrito</a>
                    <!-- Enlace al sitio web del producto -->
                    <a href="<?php echo e($producto->sitio_web); ?>" class="btn btn-light">Ver Sitio web</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('productos.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMasterMain\resources\views/productos/todo.blade.php ENDPATH**/ ?>