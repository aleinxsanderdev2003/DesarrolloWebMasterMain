<div id="header">
    <p>Teléfono: +123456789</p>
    <p>Correo: ejemplo@tudominio.com</p>
  </div>
<?php /**PATH C:\xampp\htdocs\DesarrolloWebMaster\resources\views/layout/header.blade.php ENDPATH**/ ?>