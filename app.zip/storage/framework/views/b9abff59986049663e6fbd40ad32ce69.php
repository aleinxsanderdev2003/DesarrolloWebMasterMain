<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/contacto.css')); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
<div class="content_nosotros" style="margin-top:-30px">
    <h1>Mi Página con Fondo de Imagen</h1>
  </div>

<div class="container continero mt-5" style="border-radius: 50px;
background-image: linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%);box-shadow:  20px 20px 60px #62b0d2,
             -20px -20px 60px #84eeff;">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="contact-form">
                <h1 class="text-center mb-4" style="font-family: 'Acme', sans-serif;">Contáctanos</h1>

                <form id="contactForm">
                    <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Correo Electrónico:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label class="labeli" for="mensaje">Mensaje:</label>
                        <textarea class="form-control" id="mensaje" name="mensaje" rows="4" required></textarea>
                    </div>
                    <button type="button" class="btn btn-primary" onclick="enviarMensaje()">Enviar Mensaje</button>
                <br>
                &nbsp;
                <br>
                &nbsp;
                <br>

                </form>
            </div>
        </div>
    </div>
</div>

  <script>
    function enviarMensaje() {
  // Aquí puedes agregar la lógica para enviar el mensaje y actualizar la lista de consultas recientes
  var nombre = document.getElementById("nombre").value;
  var email = document.getElementById("email").value;
  var mensaje = document.getElementById("mensaje").value;

  // Agrega la lógica para enviar el mensaje (puedes usar AJAX, Fetch, etc.)

  // Actualiza la lista de consultas recientes
  actualizarConsultas(nombre);
}

function actualizarConsultas(nombre) {
  var consultasList = document.getElementById("consultasList");
  var listItem = document.createElement("li");
  listItem.className = "list-group-item";
  listItem.textContent = "Nueva consulta - " + nombre;

  // Agrega la nueva consulta al principio de la lista
  consultasList.insertBefore(listItem, consultasList.firstChild);
}

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMasterMain\resources\views/contacto.blade.php ENDPATH**/ ?>