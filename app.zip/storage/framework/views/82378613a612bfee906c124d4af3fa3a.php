 <!-- Asumiendo que tienes un layout base -->
 
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/productomain.css')); ?>">

<div class="container-fluid">
    <div class="row">
        <!-- Barra lateral -->
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($categoria->nombre === 'Todo'): ?>
                            
                            <li class="nav-item <?php echo e(Request::is('productos') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('productos.index')); ?>">
                                    <?php echo e($categoria->nombre); ?>

                                </a>
                            </li>
                        <?php else: ?>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url("/categorias/{$categoria->nombre}")); ?>">
                                    <?php echo e($categoria->nombre); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </nav>


        <!-- Contenido principal -->
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
            <div class="container-fluid">
                <!-- Ajusta el margen superior e inferior según tus necesidades -->
                

                <!-- Agrega tu contenido específico aquí -->
                <?php echo $__env->yieldContent('contenido'); ?>
            </div>
        </main>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMasterMain\resources\views/productos/index.blade.php ENDPATH**/ ?>