<!-- resources/views/productos/landing-page.blade.php -->
@extends('layout.app')
@extends('productos.index')

@section('contenido')
    <!-- Contenido específico de la categoría 'Landing Page' -->
    <h1>Categoría: Landing Page</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Landing Page' -->
@endsection
