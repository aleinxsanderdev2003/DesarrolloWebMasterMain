<!-- resources/views/productos/paginas-web.blade.php -->
@extends('productos.index')

@section('contenido')
    <!-- Contenido específico de la categoría 'Páginas Web' -->
    <h1>Categoría: Páginas Web</h1>
    <!-- Aquí puedes mostrar los productos de la categoría 'Páginas Web' -->
@endsection
