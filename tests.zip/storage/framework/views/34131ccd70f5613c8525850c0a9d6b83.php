<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form Email</title>
</head>
<body>
    <p>Nombre: <?php echo e($data['nombre']); ?></p>
    <p>Correo Electrónico: <?php echo e($data['email']); ?></p>
    <p>Mensaje: <?php echo e($data['mensaje']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\DesarrolloWebMasterMain\resources\views/emails/contact.blade.php ENDPATH**/ ?>