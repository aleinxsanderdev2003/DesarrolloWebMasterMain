<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(asset($producto->imagen)); ?>" class="card-img-top" alt="<?php echo e($producto->nombre); ?>">
                    <div class="card-body">
                        <h2 class="card-title text-black"><?php echo e($producto->nombre); ?></h2>
                        <p class="card-text"><?php echo e($producto->descripcion); ?></p>
                        <p class="price">
                            <del>$<?php echo e($producto->precio_anterior); ?></del>
                            <ins>$<?php echo e($producto->precio_actual); ?></ins>
                        </p>
                        <a href="#" class="btn btn-primary">Añadir al carrito</a>
                        <a href="<?php echo e($producto->sitio_web); ?>" class="btn btn-light">Ver Sitio web</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DesarrolloWebMaster\resources\views/productos/Todo.blade.php ENDPATH**/ ?>